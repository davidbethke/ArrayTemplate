//#include "ArrayTHelper.h"
//#include "ArrayT.h"
//using namespace std;
// overloaded input operator for class ArrayT;
// inputs values for entire ArrayT
//not a friend for ArrayTT
/*
template<typename T>
istream & operator>>( istream &input, ArrayT<T> &a )
{
 
	a.input(input);
   return input; // enables cin >> x >> y;
} // end function 

// overloaded output operator for class ArrayT 
*/
/*
template<typename T>
ostream &operator<<( ostream &os, const ArrayT<T> &a )
{

	//a.print(os);
   return os; // enables cout << x << y;
} // end function operator<<
*/
#include "ArrayTHelper.h"
#include "ArrayT.h"
#include <iostream>
//using namespace std;
/*
template<typename T>
std::ostream &operator<<( std::ostream &os, const ArrayT<T> &a ) const
{
	a.print(os);
   return os; // enables cout << x << y;
} //
*/
